"use client";

import Reveal from "@/components/motion/Reveal";
import KitchenStatus from "@/components/ui/KitchenStatus";
import { TLink } from "@/components/motion/PageTransition";
import { useInView } from "@/lib/useInView";
import { rupees } from "@/lib/format";
import { cafe, cafeMenu } from "@/content/menu";
import { cafeHours } from "@/content/site";

/**
 * §5 · CHOCO DOODLE CAFÉ — the hard cut to light.
 * The restaurant's dark ends in chocolate, and the chocolate runs down into the
 * café: one continuous colour across the seam, so there is no line to see.
 */

const CHOC = "#3a2318";

/** [left %, drip length px, width px, drops a bead?] */
const DRIPS = [
  [2.5, 14, 30, false], [8.5, 50, 38, true], [14.5, 22, 28, false], [21, 78, 44, false],
  [28, 30, 32, false], [34.5, 58, 38, true], [41, 16, 26, false], [47.5, 92, 46, false],
  [54.5, 34, 32, false], [61, 66, 40, true], [67.5, 20, 28, false], [74, 46, 36, false],
  [80.5, 82, 44, true], [87, 26, 30, false], [93, 54, 36, false], [98.5, 18, 26, false],
] as const;

/**
 * One drip, drawn in a 40-wide box whose height keeps the bead round at any
 * length: a wide fillet out of the band, a stem, a bead a little fatter than it.
 */
function dripPath(L: number) {
  const b = L - 11; // bead centre
  const f = (n: number) => n.toFixed(1);
  return [
    "M0 0 H40",
    "C30 0 28 6 28 16",
    `V${f(b - 9)}`,
    `C28 ${f(b - 5)} 31 ${f(b - 4)} 31 ${f(b)}`,
    `A11 11 0 0 1 9 ${f(b)}`,
    `C9 ${f(b - 4)} 12 ${f(b - 5)} 12 ${f(b - 9)}`,
    "V16 C12 6 10 0 0 0 Z",
  ].join(" ");
}

function Drips() {
  const ref = useInView<HTMLDivElement>({ toggle: true, rootMargin: "0px" });
  return (
    <div ref={ref} className="choc-drips loops" aria-hidden="true">
      <svg viewBox="0 0 1200 24" preserveAspectRatio="none" className="choc-edge">
        <path
          d="M0 0 H1200 V10 C1150 16 1110 8 1060 12 S960 18 910 11 S810 6 760 12 S660 17 610 10 S510 7 460 13 S360 17 310 10 S210 6 160 12 S60 16 0 10 Z"
          fill={CHOC}
        />
      </svg>
      {DRIPS.map(([x, len, w, bead], i) => {
        const L = Math.max(34, (len * 40) / w + 22);
        return (
          <span
            key={x}
            className="drip"
            style={{ left: `${x}%`, "--w": w, "--i": i } as React.CSSProperties}
          >
            <svg viewBox={`0 0 40 ${L.toFixed(1)}`} className="block h-auto w-full">
              <path d={dripPath(L)} fill={CHOC} />
              {/* the shine that makes it wet */}
              <path d={`M16 18 V${(L - 24).toFixed(1)}`} stroke="#8a5a3c" strokeOpacity="0.5" strokeWidth="2" strokeLinecap="round" />
              <ellipse cx="15" cy={(L - 13).toFixed(1)} rx="2.8" ry="3.8" fill="#c89a78" opacity="0.32" />
            </svg>
            {bead ? <span className="bead loop" style={{ animationDelay: `${(i % 4) * 1.3 + 2.4}s` }} /> : null}
          </span>
        );
      })}
    </div>
  );
}

const ICON: Record<string, React.ReactNode> = {
  pizza: (
    <>
      <path d="M8 10 C22 2 42 2 56 10 L32 58 Z" />
      <path d="M11 16 C24 9 40 9 53 16" />
      <circle cx="26" cy="22" r="3" /><circle cx="38" cy="28" r="3" /><circle cx="31" cy="38" r="2.5" />
    </>
  ),
  pasta: (
    <>
      <path d="M6 30 H58 C58 44 46 52 32 52 C18 52 6 44 6 30 Z" />
      <path d="M20 30 C18 22 26 20 26 26 C26 32 36 30 34 22 C33 16 42 16 42 24" />
      <path d="M44 6 L36 30 M50 8 L40 30" />
    </>
  ),
  shakes: (
    <>
      <path d="M18 18 H46 L41 58 H23 Z" />
      <path d="M16 18 C16 8 48 8 48 18" />
      <path d="M36 4 L32 18" />
      <path d="M22 30 H42" />
    </>
  ),
  chocolate: (
    <>
      <rect x="8" y="16" width="48" height="36" rx="3" />
      <path d="M8 28 H56 M8 40 H56 M24 16 V52 M40 16 V52" />
      <path d="M26 16 C26 8 38 8 38 16" />
    </>
  ),
};

function Cup() {
  return (
    <div className="cafe-cup" aria-hidden="true">
      <span className="cup-steam loop" />
      <span className="cup-steam loop" style={{ animationDelay: "1.1s", left: "46%" }} />
      <span className="cup-steam loop" style={{ animationDelay: "2.2s", left: "58%" }} />
      <svg viewBox="0 0 160 120" className="relative h-auto w-full">
        <ellipse cx="72" cy="108" rx="66" ry="8" fill="#3a2318" opacity="0.12" />
        <path d="M22 40 H122 V58 C122 88 102 104 72 104 C42 104 22 88 22 58 Z" fill="#f6efe6" stroke="#3a2318" strokeWidth="2.5" />
        <path d="M122 50 C146 50 146 84 118 84" fill="none" stroke="#3a2318" strokeWidth="2.5" />
        <ellipse cx="72" cy="40" rx="50" ry="8" fill="#6b452f" stroke="#3a2318" strokeWidth="2.5" />
        <path d="M52 40 C60 34 84 34 92 40" stroke="#e8d9c5" strokeWidth="2" fill="none" opacity="0.8" />
      </svg>
    </div>
  );
}

export default function Cafe() {
  const ref = useInView<HTMLElement>({ rootMargin: "0px 0px -15% 0px" });
  const zone = useInView<HTMLDivElement>({ toggle: true, rootMargin: "0px" });

  return (
    <section ref={ref} className="cafe relative z-10 bg-cream text-cocoa" aria-labelledby="cafe-heading" style={{ colorScheme: "light" }}>
      <Drips />
      <div ref={zone} className="loops shell pb-20 pt-28 sm:pb-28 sm:pt-36">
        <div className="grid gap-12 lg:grid-cols-[1.25fr_1fr] lg:items-center">
          <div>
            <Reveal as="p" className="eyebrow !text-cocoa-soft">
              Next door · {cafe.name}
            </Reveal>
            <Reveal as="h2" id="cafe-heading" className="display-lg mt-5 max-w-[14ch] text-cocoa">
              Pizza, pasta, and a wall of chocolate.
            </Reveal>
            <Reveal as="p" className="lede measure mt-6 !text-cocoa-soft">
              Bright from half past seven in the morning until half past ten at night.
              Italian, North Indian and American on one menu — which sounds like
              indecision until you have been travelling for nine hours.
            </Reveal>
            <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-3">
              <KitchenStatus place="cafe" tone="light" />
              <p className="text-sm text-cocoa-soft">
                About <span className="tnum">{rupees(cafe.forTwo)}</span> for two ·{" "}
                <span className="tnum">{cafeHours.from}</span> – <span className="tnum">{cafeHours.to}</span>
              </p>
            </div>
          </div>
          <Cup />
        </div>

        <ul className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cafeMenu.map((c, i) => (
            <li key={c.id} className="cafe-card arrive" style={{ "--i": i } as React.CSSProperties}>
              <svg viewBox="0 0 64 64" className="cafe-icon h-14 w-14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                {ICON[c.id]}
              </svg>
              <h3 className="mt-5 font-display text-2xl text-cocoa">{c.title}</h3>
              <p className="mt-2 text-[0.9375rem] leading-relaxed text-cocoa-soft">{c.line}</p>
            </li>
          ))}
        </ul>

        <p className="mt-10 text-sm text-cocoa-soft">
          <TLink href="/dining/cafe" className="underline decoration-cocoa/30 underline-offset-4 hover:decoration-cocoa">
            More about the café
          </TLink>
        </p>
      </div>
    </section>
  );
}

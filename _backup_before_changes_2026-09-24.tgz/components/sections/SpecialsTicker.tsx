"use client";

import { useInView } from "@/lib/useInView";
import { thaliSequence, signatures } from "@/content/menu";

/**
 * The specials board, running. The first thing after the hero that says: this
 * house has a kitchen.
 */
const items = Array.from(
  new Map(
    [...thaliSequence, ...signatures.flatMap((s) => s.dishes)].map((d) => [d.name, d]),
  ).values(),
);

function Row() {
  return (
    <>
      {items.map((d) => (
        <span key={d.name} className="flex shrink-0 items-center gap-3.5 pr-6 sm:gap-4 sm:pr-7">
          <span className="font-display text-[clamp(1rem,0.9rem+0.5vw,1.3125rem)] leading-none text-rice">
            {d.name}
          </span>
          <span lang="hi" className="text-[0.8125rem] leading-none text-rice/95 sm:text-sm">
            {d.deva}
          </span>
          <svg viewBox="0 0 20 20" className="h-2.5 w-2.5 text-haldu/90" aria-hidden="true">
            <path d="M10 0 L12.5 7.5 L20 10 L12.5 12.5 L10 20 L7.5 12.5 L0 10 L7.5 7.5 Z" fill="currentColor" />
          </svg>
        </span>
      ))}
    </>
  );
}

export default function SpecialsTicker() {
  const ref = useInView<HTMLDivElement>({ toggle: true, rootMargin: "0px" });

  return (
    <div ref={ref} className="loops marquee-track relative z-10 overflow-hidden border-y border-brass/25 bg-geru py-2.5 sm:py-3">
      <p className="sr-only">
        From the kitchen: {items.map((d) => d.name).join(", ")}.
      </p>
      <div className="marquee loop" style={{ "--marquee-duration": "55s" } as React.CSSProperties} aria-hidden="true">
        <div className="flex"><Row /></div>
        <div className="flex"><Row /></div>
      </div>
    </div>
  );
}

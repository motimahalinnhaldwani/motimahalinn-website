"use client";

import Reveal from "@/components/motion/Reveal";
import HeroScene from "@/components/hero/HeroScene";
import KitchenStatus from "@/components/ui/KitchenStatus";
import WhatsAppCTA, { CallButton } from "@/components/ui/WhatsAppCTA";
import { useInView } from "@/lib/useInView";
import { bookingHref } from "@/lib/whatsapp";
import { site } from "@/content/site";

/**
 * A warm bed upstairs. A hot kitchen downstairs.
 *
 * If `site.heroVideo` is set, the walkthrough plays here instead of the
 * illustrated scene — same frame, same copy, nothing else changes.
 */
export default function Hero() {
  const ref = useInView<HTMLElement>({ toggle: true, rootMargin: "0px" });

  const facts = [
    [`${site.rating.value.toFixed(1)} / 5`, `${site.rating.count}+ guest ratings`],
    ["200 m", "from the bus stand"],
    ["Downstairs", "restaurant & café"],
    ["24 hours", "room service"],
  ];

  return (
    <section ref={ref} className="hero loops relative isolate" aria-labelledby="hero-heading">
      <div className="hero-media relative h-[54svh] min-h-[300px] overflow-hidden">
        {site.heroVideo ? (
          <video
            className="absolute inset-0 h-full w-full object-cover"
            src={site.heroVideo}
            poster={site.heroPoster ?? undefined}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            aria-label="A walkthrough of Moti Mahal Inn"
          />
        ) : (
          <HeroScene />
        )}
      </div>

      <div className="hero-copy shell relative z-10 pb-14 pt-6 lg:flex lg:min-h-[100svh] lg:items-center lg:pb-16 lg:pt-24">
        <div className="lg:max-w-[35rem]">
          <Reveal as="p" className="eyebrow mb-5" delay={0.1}>
            {site.kinds} <span aria-hidden="true">—</span> Nainital Road, Haldwani
          </Reveal>

          <Reveal
            as="h1"
            id="hero-heading"
            className="display-lg hero-title max-w-[13ch] text-rice"
            delay={0.2}
            stagger={0.08}
          >
            A warm bed upstairs. A hot kitchen downstairs.
          </Reveal>

          <Reveal as="p" className="lede mt-6 max-w-[44ch]" delay={0.45}>
            Moti Mahal Inn is a three-star hotel with its own restaurant and café,
            two hundred metres from the Haldwani bus stand — the last good night&rsquo;s
            sleep, and the last good meal, before the hills.
          </Reveal>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <WhatsAppCTA href={bookingHref()} label="Book on WhatsApp" className="loop" />
            <CallButton />
          </div>

          <KitchenStatus className="mt-6" />

          <ul className="mt-8 grid max-w-[34rem] grid-cols-2 gap-x-6 gap-y-3 text-[0.8125rem] sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
            {facts.map(([k, v]) => (
              <li key={k} className="flex flex-col">
                <span className="tnum font-display text-lg leading-tight text-brass">{k}</span>
                <span className="text-mist/70">{v}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-[0.625rem] uppercase tracking-[0.3em] text-mist/65 lg:flex" aria-hidden="true">
        Come in
        <span className="scroll-cue loop" />
      </div>
    </section>
  );
}

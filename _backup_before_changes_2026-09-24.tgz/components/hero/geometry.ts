/**
 * Deterministic geometry for the hero scene. Generated once at module scope,
 * so the server and the client draw exactly the same picture.
 * Coordinates are in a 1600 × 900 viewBox.
 */

function rng(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const f = (n: number) => n.toFixed(1);

export const stars = (() => {
  const r = rng(11);
  return Array.from({ length: 72 }, (_, i) => ({
    x: r() * 1600,
    y: 12 + Math.pow(r(), 1.7) * 400,
    r: 0.5 + r() * 1.2,
    o: 0.3 + r() * 0.65,
    twinkle: i % 9 === 0,
    d: `${(r() * 4).toFixed(2)}s`,
  }));
})();

type Peak = { x: number; h: number; w: number };

function ridge(
  base: number,
  heightAt: (x: number) => number,
  step = 10,
): { d: string; yAt: (x: number) => number } {
  const yAt = (x: number) => base - heightAt(x);
  let d = `M0 900 L0 ${f(yAt(0))}`;
  for (let x = step; x <= 1600; x += step) d += ` L${x} ${f(yAt(x))}`;
  return { d: `${d} L1600 900 Z`, yAt };
}

/* The high Himalaya, pale and far. */
const peaks: Peak[] = [
  { x: 170, h: 70, w: 150 },
  { x: 380, h: 104, w: 170 },
  { x: 610, h: 82, w: 140 },
  { x: 800, h: 132, w: 190 },
  { x: 1040, h: 96, w: 160 },
  { x: 1260, h: 118, w: 170 },
  { x: 1500, h: 88, w: 150 },
];
const jag = rng(3);
const jitter = Array.from({ length: 170 }, () => jag() * 9);
export const himalaya = ridge(512, (x) => {
  let h = 8;
  for (const p of peaks) h += Math.pow(Math.max(0, 1 - Math.abs(x - p.x) / p.w), 1.25) * p.h;
  return h + jitter[Math.round(x / 10)];
}, 10);

/* Snow: a band hanging from the crest, deeper on the higher peaks. A flat
   clip at a fixed height drew a ruler-straight line across every mountain. */
export const snow = (() => {
  const top: string[] = [];
  const bottom: string[] = [];
  for (let x = 0; x <= 1600; x += 10) {
    const y = himalaya.yAt(x);
    const depth = Math.max(0, Math.min(46, (478 - y) * 0.75));
    top.push(`${x} ${f(y)}`);
    bottom.push(`${x} ${f(y + depth)}`);
  }
  return `M${top.join(" L")} L${bottom.reverse().join(" L")} Z`;
})();

/* Two nearer ranges — the Shivalik — the second carrying deodar on its crest. */
export const haze = ridge(
  590,
  (x) => 34 + 26 * Math.sin(x / 150 + 1) + 14 * Math.sin(x / 61 + 2) + 6 * Math.sin(x / 23),
  12,
);

const near = ridge(
  652,
  (x) => 30 + 30 * Math.sin(x / 200 + 0.4) + 12 * Math.sin(x / 73 + 3) + 5 * Math.sin(x / 19),
  8,
);
export const shivalik = near.d;
export const deodars = (() => {
  const r = rng(7);
  let d = "";
  for (let x = 4; x < 1600; x += 9 + r() * 7) {
    if (r() < 0.22) continue;
    const y = near.yAt(x) + 3;
    const h = 9 + r() * 20;
    const w = 3.5 + r() * 3;
    d += `M${f(x - w)} ${f(y)} L${f(x)} ${f(y - h)} L${f(x + w)} ${f(y)} Z `;
  }
  return d;
})();

/* The town of Haldwani at the foot of it all. */
export const townHill = ridge(726, (x) => 10 + 8 * Math.sin(x / 130) + 4 * Math.sin(x / 41), 16).d;
export const town = (() => {
  const r = rng(19);
  const blocks: { x: number; y: number; w: number; h: number }[] = [];
  const lights: { x: number; y: number; o: number }[] = [];
  for (let x = -10; x < 930; ) {
    const w = 24 + r() * 40;
    const h = 26 + r() * (x > 360 && x < 520 ? 40 : 88);
    const y = 812 - h;
    blocks.push({ x, y, w, h });
    for (let wy = y + 8; wy < 804; wy += 11)
      for (let wx = x + 5; wx < x + w - 6; wx += 9)
        if (r() < 0.13) lights.push({ x: wx, y: wy, o: 0.45 + r() * 0.5 });
    x += w + 2 + r() * 6;
  }
  return { blocks, lights };
})();

/* The inn. Three floors of rooms over a restaurant and a café. */
export const WIN = { w: 44, h: 50, cols: [1017, 1091, 1165, 1239, 1313, 1387], rows: [452, 544, 636] };
const DARK = new Set([2, 7, 13, 16]);
const FLICK = new Set([4, 10]);
export const windows = (() => {
  const r = rng(23);
  /* Fisher–Yates, not sort(() => r() - 0.5): a comparator shuffle depends on
     the engine's sort algorithm, so Safari and Node would disagree and the
     server-rendered delays would not match the client's. */
  const order = Array.from({ length: 18 }, (_, i) => i);
  for (let k = order.length - 1; k > 0; k--) {
    const j = Math.floor(r() * (k + 1));
    [order[k], order[j]] = [order[j], order[k]];
  }
  return WIN.rows.flatMap((y, row) =>
    WIN.cols.map((x, col) => {
      const i = row * 6 + col;
      return {
        i,
        x,
        y,
        lit: !DARK.has(i),
        flick: FLICK.has(i),
        ac: (i + row) % 3 === 0,
        d: `${400 + order.indexOf(i) * 110}ms`,
      };
    }),
  );
})();

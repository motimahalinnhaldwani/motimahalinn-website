"use client";

import { useEffect, useRef } from "react";
import { prefersReducedMotion } from "@/lib/tier";
import { lerp } from "@/lib/format";
import {
  stars,
  himalaya,
  snow,
  haze,
  shivalik,
  deodars,
  townHill,
  town,
  windows,
  WIN,
} from "./geometry";

/**
 * Dusk at Moti Mahal Inn.
 *
 * The rooms upstairs light up one by one, the restaurant and café signs
 * flicker on, the kitchen vents steam, and the hills fall away behind in
 * layers. Each layer is its own HTML element so parallax runs on the
 * compositor — transforms on SVG children would repaint the whole drawing
 * every frame.
 *
 * Scroll parallax is a CSS scroll-driven animation (no JavaScript). Pointer
 * parallax uses the separate `translate` property so the two compose.
 */

const VB = "0 0 1600 900";
const FIT = "xMaxYMax slice";

function Layer({
  name,
  depth,
  children,
  defs,
}: {
  name: string;
  depth: number;
  children: React.ReactNode;
  defs?: React.ReactNode;
}) {
  return (
    <div className={`scene-layer scene-${name}`} data-depth={depth} aria-hidden="true">
      <svg viewBox={VB} preserveAspectRatio={FIT} focusable="false">
        {defs ? <defs>{defs}</defs> : null}
        {children}
      </svg>
    </div>
  );
}

export default function HeroScene() {
  const root = useRef<HTMLDivElement>(null);

  /* Pointer parallax, desktop only. One rAF that stops when it has caught up. */
  useEffect(() => {
    const el = root.current;
    if (!el || prefersReducedMotion() || !matchMedia("(pointer: fine)").matches) return;

    const layers = Array.from(el.querySelectorAll<HTMLElement>("[data-depth]"));
    const target = { x: 0, y: 0 };
    const pos = { x: 0, y: 0 };
    let raf = 0;

    const tick = () => {
      pos.x = lerp(pos.x, target.x, 0.08);
      pos.y = lerp(pos.y, target.y, 0.08);
      for (const l of layers) {
        const d = Number(l.dataset.depth);
        l.style.translate = `${(pos.x * d).toFixed(2)}px ${(pos.y * d * 0.4).toFixed(2)}px`;
      }
      raf =
        Math.abs(pos.x - target.x) > 0.002 || Math.abs(pos.y - target.y) > 0.002
          ? requestAnimationFrame(tick)
          : 0;
    };

    const section = el.closest("section") ?? el;
    const onMove = (e: PointerEvent) => {
      target.x = (e.clientX / innerWidth - 0.5) * -2;
      target.y = (e.clientY / innerHeight - 0.5) * -2;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const onLeave = () => {
      target.x = 0;
      target.y = 0;
      if (!raf) raf = requestAnimationFrame(tick);
    };

    section.addEventListener("pointermove", onMove as EventListener, { passive: true });
    section.addEventListener("pointerleave", onLeave);
    return () => {
      cancelAnimationFrame(raf);
      section.removeEventListener("pointermove", onMove as EventListener);
      section.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  return (
    <div ref={root} className="scene" role="img" aria-label="Moti Mahal Inn at dusk: rooms lit on three floors above the restaurant and café, the Kumaon hills behind.">
      {/* ── sky: stars and a new moon ─────────────────────────────── */}
      <Layer
        name="sky"
        depth={4}
        defs={
          <radialGradient id="moonGlow">
            <stop offset="0" stopColor="#f3e9d6" stopOpacity="0.28" />
            <stop offset="1" stopColor="#f3e9d6" stopOpacity="0" />
          </radialGradient>
        }
      >
        {stars.map((s, i) => (
          <circle
            key={i}
            cx={s.x.toFixed(1)}
            cy={s.y.toFixed(1)}
            r={s.r.toFixed(2)}
            fill="#f4ede2"
            opacity={s.o.toFixed(2)}
            className={s.twinkle ? "twinkle loop" : undefined}
            style={s.twinkle ? ({ "--d": s.d } as React.CSSProperties) : undefined}
          />
        ))}
        <circle cx="1238" cy="126" r="80" fill="url(#moonGlow)" />
        <circle cx="1238" cy="126" r="21" fill="#f3e9d6" />
        <circle cx="1229" cy="121" r="19" fill="#0e0f1f" />
      </Layer>

      {/* ── the high Himalaya, snow catching the last light ────────── */}
      <Layer
        name="far"
        depth={8}
        defs={
          <>
            <linearGradient id="alpenglow" x1="0" x2="1" y1="0" y2="0">
              <stop offset="0" stopColor="#aab4cc" />
              <stop offset="0.55" stopColor="#d7b2b0" />
              <stop offset="1" stopColor="#e7b891" />
            </linearGradient>
          </>
        }
      >
        <path d={himalaya.d} fill="#252b3e" />
        <path d={snow} fill="url(#alpenglow)" opacity="0.5" />
      </Layer>

      {/* ── the Shivalik, and deodar on the crest ─────────────────── */}
      <Layer name="mid" depth={14}>
        <path d={haze.d} fill="#1a1f2d" />
        <path d={shivalik} fill="#121917" />
        <path d={deodars} fill="#121917" />
      </Layer>

      {/* ── Haldwani ──────────────────────────────────────────────── */}
      <Layer name="town" depth={20}>
        <path d={townHill} fill="#0d1110" />
        {town.blocks.map((b, i) => (
          <rect key={i} x={b.x.toFixed(1)} y={b.y.toFixed(1)} width={b.w.toFixed(1)} height={b.h.toFixed(1)} fill="#0b0e0d" />
        ))}
        {town.lights.map((l, i) => (
          <rect key={`l${i}`} x={l.x.toFixed(1)} y={l.y.toFixed(1)} width="3" height="4" fill="#e3b064" opacity={l.o.toFixed(2)} />
        ))}
        {/* a temple spire, with its flag */}
        <path d="M418 812 L418 742 L452 742 L452 812 Z M414 744 Q435 670 435 656 Q435 670 456 744 Z" fill="#0b0e0d" />
        <circle cx="435" cy="652" r="4" fill="#0b0e0d" />
        <path d="M435 652 L435 626" stroke="#0b0e0d" strokeWidth="1.5" />
        <path d="M435 627 L453 633 L435 639 Z" fill="#9c3b24" />
      </Layer>

      {/* ── the inn, the street, and a parked auto ───────────────── */}
      <Layer
        name="inn"
        depth={26}
        defs={
          <>
            <linearGradient id="facade" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#1f1914" />
              <stop offset="1" stopColor="#140f0c" />
            </linearGradient>
            <linearGradient id="winLit" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#ffe7ac" />
              <stop offset="0.6" stopColor="#f2b75d" />
              <stop offset="1" stopColor="#d88b3c" />
            </linearGradient>
            <linearGradient id="shopLit" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#ffe2a4" />
              <stop offset="1" stopColor="#e3913f" />
            </linearGradient>
            <linearGradient id="cafeLit" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#fff0d8" />
              <stop offset="1" stopColor="#eab574" />
            </linearGradient>
            <radialGradient id="signGlow">
              <stop offset="0" stopColor="#f4b659" stopOpacity="0.55" />
              <stop offset="1" stopColor="#f4b659" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="innGlow">
              <stop offset="0" stopColor="#f0a64a" stopOpacity="0.5" />
              <stop offset="1" stopColor="#f0a64a" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="spill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#ffcf7a" stopOpacity="0.75" />
              <stop offset="1" stopColor="#ffcf7a" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="cone" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#ffe6a8" stopOpacity="0.55" />
              <stop offset="1" stopColor="#ffe6a8" stopOpacity="0" />
            </linearGradient>
          </>
        }
      >
        {/* warmth thrown on the sky by a lit building */}
        <ellipse className="glow-in" cx="1224" cy="660" rx="460" ry="230" fill="url(#innGlow)" />

        {/* street */}
        <rect x="0" y="812" width="1600" height="88" fill="#0a0b0a" />
        <rect x="0" y="812" width="1600" height="2" fill="#29251f" />
        {[40, 170, 300, 430, 560, 690, 1500].map((x) => (
          <rect key={x} x={x} y="864" width="46" height="3" fill="#39352c" opacity="0.6" />
        ))}

        {/* stair tower + main block */}
        <rect x="944" y="394" width="44" height="418" fill="#16120e" />
        {[470, 562, 654].map((y, i) => (
          <rect key={y} className="win-lit" x="959" y={y} width="12" height="28" fill="url(#winLit)" style={{ "--d": `${250 + i * 90}ms` } as React.CSSProperties} />
        ))}
        <rect x="986" y="432" width="476" height="380" fill="url(#facade)" />
        <rect x="1458" y="432" width="4" height="380" fill="#2c241b" />
        <rect x="980" y="420" width="488" height="14" fill="#241e17" />
        {[526, 618].map((y) => (
          <rect key={y} x="986" y={y} width="476" height="4" fill="#2a2319" />
        ))}
        <rect x="986" y="706" width="476" height="6" fill="#2a2319" />

        {/* rooms: three floors, six windows each */}
        {windows.map((w) => (
          <g key={w.i}>
            <rect x={w.x - 3} y={w.y - 3} width={WIN.w + 6} height={WIN.h + 6} fill="#0c0a08" />
            <rect x={w.x} y={w.y} width={WIN.w} height={WIN.h} fill="#1f1b17" />
            {w.lit ? (
              <g className={`win-lit${w.flick ? " win-flick loop" : ""}`} style={{ "--d": w.d } as React.CSSProperties}>
                <rect x={w.x} y={w.y} width={WIN.w} height={WIN.h} fill="url(#winLit)" />
                <rect x={w.x + WIN.w - 13} y={w.y} width="13" height={WIN.h} fill="#9f5f2b" opacity="0.55" />
              </g>
            ) : null}
            <rect x={w.x + WIN.w / 2 - 1} y={w.y} width="2" height={WIN.h} fill="#0c0a08" />
            <rect x={w.x - 4} y={w.y + WIN.h + 3} width={WIN.w + 8} height="3" fill="#2a231a" />
            {w.ac ? <rect x={w.x + WIN.w + 6} y={w.y + WIN.h - 16} width="16" height="13" rx="1.5" fill="#2a2520" /> : null}
          </g>
        ))}

        {/* rooftop sign */}
        <rect x="1070" y="390" width="4" height="32" fill="#1a1612" />
        <rect x="1370" y="390" width="4" height="32" fill="#1a1612" />
        <rect className="sign-on" style={{ "--d": "1500ms" } as React.CSSProperties} x="1020" y="330" width="404" height="92" fill="url(#signGlow)" />
        <rect x="1048" y="356" width="348" height="36" fill="#0d0b09" stroke="#6b5230" strokeWidth="1" />
        <text className="sign-on font-sans" style={{ "--d": "1500ms" } as React.CSSProperties} x="1222" y="382" textAnchor="middle" fontSize="23" fontWeight="600" letterSpacing="7" fill="#f3c46e">
          MOTI MAHAL INN
        </text>
        <rect x="1410" y="392" width="38" height="28" fill="#1b1713" />
        <rect x="1406" y="388" width="46" height="5" fill="#241e17" />

        {/* kitchen exhaust, steaming */}
        <rect x="1462" y="690" width="14" height="8" fill="#1f1a15" />
        <rect x="1466" y="600" width="10" height="98" fill="#1f1a15" />
        <rect x="1463" y="594" width="16" height="8" fill="#29221b" />
        {[0, 1, 2].map((k) => (
          <ellipse
            key={k}
            className="steam loop"
            style={{ "--d": `${k * 1.3}s` } as React.CSSProperties}
            cx="1471"
            cy="584"
            rx="9"
            ry="12"
            fill="#d9d2c6"
          />
        ))}

        {/* ── restaurant ── */}
        <rect className="sign-on" style={{ "--d": "2300ms" } as React.CSSProperties} x="984" y="706" width="252" height="52" fill="url(#signGlow)" />
        <rect x="998" y="720" width="224" height="26" fill="#0d0b09" stroke="#6b5230" strokeWidth="1" />
        <text className="sign-on font-sans" style={{ "--d": "2300ms" } as React.CSSProperties} x="1110" y="738" textAnchor="middle" fontSize="13" fontWeight="600" letterSpacing="2.4" fill="#f3c46e">
          MOTIMAHAL RESTAURANT
        </text>
        {[1000, 1074, 1148].map((x) => (
          <rect key={x} x={x - 2} y="750" width="72" height="60" fill="#0c0a08" />
        ))}
        <g className="shop-lit" style={{ "--d": "1900ms" } as React.CSSProperties}>
          {[1000, 1074, 1148].map((x) => (
            <rect key={x} x={x} y="752" width="68" height="56" fill="url(#shopLit)" />
          ))}
          {/* diners */}
          <g fill="#3a2414" opacity="0.78">
            <rect x="1010" y="792" width="48" height="4" />
            <circle cx="1021" cy="779" r="6" /><ellipse cx="1021" cy="791" rx="10" ry="6" />
            <circle cx="1048" cy="780" r="6" /><ellipse cx="1048" cy="792" rx="10" ry="6" />
            <rect x="1084" y="794" width="46" height="4" />
            <circle cx="1096" cy="781" r="6" /><ellipse cx="1096" cy="793" rx="10" ry="6" />
            <circle cx="1124" cy="768" r="5.5" /><rect x="1118" y="774" width="12" height="34" rx="4" />
            <rect x="1158" y="792" width="48" height="4" />
            <circle cx="1170" cy="779" r="6" /><ellipse cx="1170" cy="791" rx="10" ry="6" />
            <circle cx="1195" cy="780" r="6" /><ellipse cx="1195" cy="792" rx="10" ry="6" />
          </g>
          {/* the door, open */}
          <rect x="1226" y="738" width="50" height="74" fill="#ffd48a" />
          <path d="M1226 738 L1241 743 L1241 807 L1226 812 Z" fill="#2a1c12" />
          <path d="M1224 812 L1278 812 L1324 868 L1178 868 Z" fill="url(#spill)" />
          <circle cx="1251" cy="729" r="3" fill="#ffe1a0" />
        </g>
        <rect x="1222" y="734" width="58" height="4" fill="#0c0a08" />

        {/* ── café ── */}
        <rect className="sign-on" style={{ "--d": "2700ms" } as React.CSSProperties} x="1280" y="706" width="184" height="50" fill="url(#signGlow)" />
        <rect x="1290" y="720" width="162" height="26" fill="#e9dcc7" />
        <text className="sign-on" style={{ "--d": "2700ms", fontFamily: "var(--font-display)" } as React.CSSProperties} x="1371" y="738.5" textAnchor="middle" fontSize="15" fontStyle="italic" fill="#3a2318">
          Choco Doodle Café
        </text>
        {Array.from({ length: 11 }, (_, k) => (
          <rect key={k} x={1290 + k * 14.73} y="748" width="14.73" height="18" fill={k % 2 ? "#6b452f" : "#e9dcc7"} />
        ))}
        {Array.from({ length: 11 }, (_, k) => (
          <circle key={`s${k}`} cx={1297.4 + k * 14.73} cy="766" r="7.3" fill={k % 2 ? "#6b452f" : "#e9dcc7"} />
        ))}
        <rect x="1292" y="774" width="158" height="36" fill="#0c0a08" />
        <g className="shop-lit" style={{ "--d": "2100ms" } as React.CSSProperties}>
          <rect x="1294" y="776" width="154" height="32" fill="url(#cafeLit)" />
          <g fill="#6b452f" opacity="0.7">
            <rect x="1302" y="786" width="60" height="2" />
            <rect x="1302" y="797" width="60" height="2" />
            {[1308, 1320, 1332, 1344, 1356].map((x) => (
              <circle key={x} cx={x} cy="782" r="3" />
            ))}
            <rect x="1380" y="790" width="60" height="18" />
          </g>
        </g>

        {/* street lamp */}
        <path className="lamp-on" style={{ "--d": "600ms" } as React.CSSProperties} d="M930 594 L940 594 L1012 812 L858 812 Z" fill="url(#cone)" />
        <rect x="898" y="588" width="5" height="224" fill="#1b1a17" />
        <path d="M900 596 Q900 584 916 584 L934 584" stroke="#1b1a17" strokeWidth="3" fill="none" />
        <path d="M926 583 L944 583 L940 592 L930 592 Z" fill="#2a2722" />
        <ellipse className="lamp-on" style={{ "--d": "600ms" } as React.CSSProperties} cx="935" cy="593" rx="5" ry="2.5" fill="#ffe9b8" />

        {/* an auto, waiting for the next arrival off the bus */}
        <g>
          <path d="M760 806 L764 786 Q767 774 780 772 L838 772 Q848 772 850 784 L850 806 Z" fill="#26331c" />
          <path d="M768 772 L774 757 Q776 753 782 753 L840 753 Q846 753 846 759 L846 772 Z" fill="#161b12" />
          <path d="M769 786 L773 775 L788 775 L788 786 Z" fill="#3a4033" opacity="0.8" />
          <circle cx="763" cy="798" r="2.2" fill="#ffe7a8" />
          <circle cx="768" cy="809" r="7" fill="#080808" />
          <circle cx="836" cy="809" r="8" fill="#080808" />
        </g>
      </Layer>

      <div className="scene-shade" aria-hidden="true" />
      {/* now and then, a shooting star over the hills */}
      <span className="shooting-star loop" aria-hidden="true" style={{ "--x": "56%", "--y": "8%", "--delay": "3.5s", "--dur": "14s" } as React.CSSProperties} />
      <span className="shooting-star loop" aria-hidden="true" style={{ "--x": "86%", "--y": "20%", "--delay": "11s", "--dur": "19s" } as React.CSSProperties} />
    </div>
  );
}

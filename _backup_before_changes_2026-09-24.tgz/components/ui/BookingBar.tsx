"use client";

import { useEffect, useId, useState } from "react";
import { usePathname } from "next/navigation";
import { useUI } from "@/lib/store";
import { bookingHref, nightsBetween } from "@/lib/whatsapp";
import { WhatsAppGlyph, CallButton, BellGlyph } from "./WhatsAppCTA";
import { telHref } from "@/lib/whatsapp";

/**
 * §8.1 — docks after the hero. On a desktop: dates and guests, then WhatsApp or
 * a call. On a phone: just the two buttons that matter, one thumb away.
 */

function isoDay(offset = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export default function BookingBar() {
  const pastHero = useUI((s) => s.pastHero);
  const id = useId();
  const [today, setToday] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [adults, setAdults] = useState(2);
  // Step aside while the full composer or the footer is on screen — no point showing two booking forms.
  const [covered, setCovered] = useState(false);
  const docked = pastHero && !covered;
  const path = usePathname();

  useEffect(() => {
    setCovered(false);
    const els = document.querySelectorAll(".stay-card, footer");
    const seen = new Set<Element>();
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) e.isIntersecting ? seen.add(e.target) : seen.delete(e.target);
      setCovered(seen.size > 0);
    });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [path]);

  useEffect(() => {
    setToday(isoDay(0));
    setCheckIn((v) => v || isoDay(0));
    setCheckOut((v) => v || isoDay(1));
  }, []);

  const bad = nightsBetween(checkIn, checkOut) <= 0;
  const field = "tnum w-full rounded-sm border border-brass/25 bg-ink/70 px-3 py-2 text-sm text-rice";
  const label = "text-[0.625rem] uppercase tracking-[0.18em] text-mist/70";

  return (
    <>
      <div
        data-docked={docked}
        className="pointer-events-none fixed inset-x-0 bottom-0 z-40 hidden translate-y-full opacity-0 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] data-[docked=true]:pointer-events-auto data-[docked=true]:translate-y-0 data-[docked=true]:opacity-100 lg:block"
      >
        <div className="shell pb-5">
          <form
            onSubmit={(e) => e.preventDefault()}
            aria-label="Check availability"
            className="flex items-end gap-4 rounded-sm border border-brass/30 bg-ink-soft/97 p-4 shadow-[0_-8px_40px_rgba(0,0,0,0.45)]"
          >
            <div className="grid flex-1 grid-cols-3 gap-4">
              <div className="flex flex-col gap-1">
                <label htmlFor={`${id}-in`} className={label}>Check in</label>
                <input id={`${id}-in`} type="date" min={today} value={checkIn}
                  onChange={(e) => {
                    setCheckIn(e.target.value);
                    if (nightsBetween(e.target.value, checkOut) <= 0) {
                      const d = new Date(`${e.target.value}T12:00:00`);
                      d.setDate(d.getDate() + 1);
                      setCheckOut(d.toISOString().slice(0, 10));
                    }
                  }}
                  className={field} />
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor={`${id}-out`} className={label}>Check out</label>
                <input id={`${id}-out`} type="date" min={checkIn || today} value={checkOut}
                  onChange={(e) => setCheckOut(e.target.value)} className={field} />
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor={`${id}-adults`} className={label}>Guests</label>
                <select id={`${id}-adults`} value={adults} onChange={(e) => setAdults(Number(e.target.value))} className={field}>
                  {[1, 2, 3, 4].map((n) => <option key={n} value={n}>{n} {n === 1 ? "guest" : "guests"}</option>)}
                </select>
              </div>
            </div>
            <a
              href={bookingHref({ checkIn, checkOut, adults })}
              target="_blank"
              rel="noopener noreferrer"
              aria-disabled={bad}
              onClick={(e) => bad && e.preventDefault()}
              className="sheen inline-flex items-center gap-2 rounded-sm bg-brass px-5 py-2.5 text-[0.8125rem] font-medium uppercase tracking-[0.12em] text-ink transition-colors hover:bg-haldu aria-disabled:opacity-50"
            >
              <WhatsAppGlyph /> Check availability
            </a>
            <CallButton label="Call" className="!py-2.5" />
          </form>
        </div>
      </div>

      <div
        data-docked={docked}
        className="pointer-events-none fixed inset-x-0 bottom-0 z-40 translate-y-full opacity-0 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] data-[docked=true]:pointer-events-auto data-[docked=true]:translate-y-0 data-[docked=true]:opacity-100 lg:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="flex gap-2 border-t border-brass/25 bg-ink-soft/97 p-3">
          <a href={telHref} className="bell-btn inline-flex flex-1 items-center justify-center gap-2 rounded-sm border border-brass/45 px-4 py-3 text-[0.8125rem] uppercase tracking-[0.12em] text-rice">
            <BellGlyph className="h-[1.1rem] w-[1.1rem] text-brass" /> Call
          </a>
          <a href={bookingHref()} target="_blank" rel="noopener noreferrer" className="inline-flex flex-[1.4] items-center justify-center gap-2 whitespace-nowrap rounded-sm bg-brass px-3 py-3 text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-ink">
            <WhatsAppGlyph /> Book on WhatsApp
          </a>
        </div>
      </div>
    </>
  );
}

import type { Metadata } from "next";

import Hero from "@/components/sections/Hero";
import SpecialsTicker from "@/components/sections/SpecialsTicker";
import Gateway from "@/components/sections/Gateway";
import StayDine from "@/components/sections/StayDine";
import Rooms from "@/components/sections/Rooms";
import Kitchen from "@/components/sections/Kitchen";
import Cafe from "@/components/sections/Cafe";
import BookDirect from "@/components/sections/BookDirect";
import FindUs from "@/components/sections/FindUs";
import AipanThreshold from "@/components/motion/AipanThreshold";
import JsonLd from "@/components/ui/JsonLd";

import { faqSchema, distanceFaqs, restaurantSchema, cafeSchema } from "@/lib/seo";
import { site } from "@/content/site";

export const metadata: Metadata = {
  title: `${site.name} — Hotel, Restaurant & Café in Haldwani`,
  description: site.description,
  alternates: { canonical: "/" },
};

/**
 * The house, from the street in: the hotel lit up at dusk, what the kitchen is
 * cooking, where it sits on the road into the hills, the two doors in, the rooms upstairs, the restaurant and the café
 * downstairs, and how to book a room without a middleman.
 */
export default function Home() {
  return (
    <>
      <Hero />
      <SpecialsTicker />
      <Gateway />
      <StayDine />
      <Rooms />
      <AipanThreshold variant="jyoti" label="Downstairs" />
      <Kitchen />
      <Cafe />
      <BookDirect />
      <FindUs />
      <JsonLd data={[faqSchema(distanceFaqs), restaurantSchema(), cafeSchema()]} />
    </>
  );
}

import type { Metadata } from "next";
import PageHeader from "@/components/ui/PageHeader";
import Cafe from "@/components/sections/Cafe";
import Frame from "@/components/ui/Frame";
import JsonLd from "@/components/ui/JsonLd";
import { cafe } from "@/content/menu";
import { images } from "@/content/images";
import { cafeSchema, breadcrumbSchema } from "@/lib/seo";

export const metadata: Metadata = {
  title: "Choco Doodle Café",
  description:
    "Choco Doodle Café at Moti Mahal Inn, Haldwani — pizza, pasta, shakes and a counter of chocolates that keep six months without a fridge. Open 7:30 a.m. to 10:30 p.m.",
  alternates: { canonical: "/dining/cafe" },
};

export default function CafePage() {
  return (
    <>
      <PageHeader
        eyebrow={cafe.name}
        title="Pizza, pasta, and a wall of chocolate."
        lede="Next to the restaurant, bright from breakfast until half past ten at night."
        trail={[
          { name: "Home", href: "/" },
          { name: "Café", href: "/dining/cafe" },
        ]}
      />
      <div className="shell mt-14 pb-10">
        <Frame img={images.cafeRoom} className="w-full" sizes="100vw" priority />
      </div>
      <Cafe />
      <JsonLd data={[cafeSchema(), breadcrumbSchema([{ name: "Home", href: "/" }, { name: "Café", href: "/dining/cafe" }])]} />
    </>
  );
}

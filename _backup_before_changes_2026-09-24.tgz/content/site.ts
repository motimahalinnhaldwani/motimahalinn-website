/**
 * Moti Mahal Inn — ground truth.
 * One place for every fact the site states out loud.
 */

/** Calls and WhatsApp both go here. The number must have WhatsApp active. */
export const PHONE = "+916397359584";
export const WHATSAPP = "916397359584";

export const site = {
  name: "Moti Mahal Inn",
  nameDeva: "मोती महल इन",
  legalName: "Motimahal Inn",
  kinds: "Hotel · Restaurant · Café",
  description:
    "A three-star hotel with its own restaurant and café on Nainital Road, Haldwani — two hundred metres from the bus stand.",
  url: "https://motimahalinn.com",
  phone: PHONE,
  phoneDisplay: "+91 63973 59584",
  whatsapp: WHATSAPP,
  address: {
    street: "Nainital Road (NH-87), opposite SDM Court",
    locality: "Haldwani",
    region: "Uttarakhand",
    district: "Nainital",
    postalCode: "263139",
    country: "IN",
  },
  geo: { lat: 29.2183, lng: 79.513 },
  rating: { value: 4.0, count: 600, on: ["Goibibo", "Cleartrip", "TripAdvisor"] },
  rates: { min: 1750, max: 4250, currency: "INR" },
  checkIn: "12:00",
  checkOut: "10:00",
  stars: 3,
  /**
   * The hotel walkthrough. Drop an .mp4 in /public/video and set these, and it
   * replaces the illustrated scene in the hero. Keep it under ~4 MB.
   */
  heroVideo: null as string | null,
  heroPoster: null as string | null,
} as const;

/** Minutes after midnight, IST. Drives the "kitchen open now" status. */
export const meals = [
  { label: "Breakfast", from: "7:30", to: "12:00", start: 450, end: 720 },
  { label: "Lunch", from: "12:00", to: "5:30", start: 720, end: 1050 },
  { label: "Dinner", from: "5:30", to: "11:00", start: 1050, end: 1380 },
] as const;

export const cafeHours = { from: "7:30 a.m.", to: "10:30 p.m.", start: 450, end: 1350 } as const;

/** Getting here — the transit points, from the front door. */
export const distances = [
  { place: "Haldwani bus station", short: "Bus stand", display: "200 m", time: "3 min walk", mode: "bus", note: "A three-minute walk." },
  { place: "Haldwani railway station", short: "Haldwani station", display: "750 m", time: "10 min walk", mode: "train", note: "Ten minutes on foot, three by auto." },
  { place: "Kathgodam railway station", short: "Kathgodam station", display: "6.2 km", time: "15 min drive", mode: "train", note: "Where the line ends and the hills begin." },
  { place: "Pantnagar Airport", short: "Pantnagar airport", display: "32.5 km", time: "50 min drive", mode: "plane", note: "About fifty minutes by road." },
] as const;

/**
 * Up the hill — approximate road distances and drive times from Haldwani.
 * Facts for travellers, not a tour service.
 */
export const places = [
  { id: "bhimtal", place: "Bhimtal", deva: "भीमताल", km: 25, drive: "50 min", note: "A bigger lake than Naini, and quieter." },
  { id: "nainital", place: "Nainital", deva: "नैनीताल", km: 38, drive: "1 hr 15 min", note: "The lake town everyone comes up for." },
  { id: "kainchi", place: "Kainchi Dham", deva: "कैंची धाम", km: 38, drive: "1 hr 15 min", note: "Neem Karoli Baba’s ashram, in the Kosi valley." },
  { id: "corbett", place: "Jim Corbett", deva: "जिम कॉर्बेट", km: 52, drive: "1 hr 30 min", note: "Ramnagar, for the national park gates." },
  { id: "mukteshwar", place: "Mukteshwar", deva: "मुक्तेश्वर", km: 70, drive: "2 hr 15 min", note: "Orchards, and the snows on a clear morning." },
  { id: "almora", place: "Almora", deva: "अल्मोड़ा", km: 87, drive: "3 hr", note: "The old Kumaoni capital, along its ridge." },
] as const;

export const amenities = [
  { label: "Restaurant & café", icon: "plate" },
  { label: "24-hour room service", icon: "bell" },
  { label: "Air conditioning", icon: "ac" },
  { label: "Free Wi-Fi", icon: "wifi" },
  { label: "Daily housekeeping", icon: "broom" },
  { label: "Luggage storage", icon: "bag" },
  { label: "Doctor on call", icon: "cross" },
  { label: "Parking", icon: "car" },
  { label: "Laundry", icon: "shirt" },
] as const;

export const nav = [
  { href: "/rooms", label: "Rooms" },
  { href: "/dining/restaurant", label: "Restaurant" },
  { href: "/dining/cafe", label: "Café" },
  { href: "/gallery", label: "Gallery" },
  { href: "/contact", label: "Contact" },
] as const;

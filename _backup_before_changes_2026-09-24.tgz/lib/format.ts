const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export const rupees = (n: number) => inr.format(n);

/** Bare figure with Indian grouping, for places the ₹ is already set in type. */
export const figure = (n: number) => new Intl.NumberFormat("en-IN").format(n);

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const clamp = (v: number, min = 0, max = 1) => Math.min(max, Math.max(min, v));
